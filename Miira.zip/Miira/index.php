<?php get_header()?>
<section class="light parallax" id="menu">
            <div class="wrap menu">
            <h2 class="brn wow fadeInLeft">Packages</h2>
            <ul class="filter wow fadeInUp">
                <li><a href="#wedding" class="active">Weddings</a></li>
                <li><a href="#birthday">Birthdays</a></li>
                <li><a href="#graduation">Graduations</a></li>
                <li><a href="#ruracio">Ruracios</a></li>
            </ul>
            <div class="menu-card wow fadeInUp">
                <!-- main id -->
                <div  id="wedding" class="card" >
                <div class="full main">
                    <h3>Weddings</h3>
                </div>
                <div class="half">
                    <ul>
                        <li>Buffet<span class="price"><input value="100" id="buffet" name="buffet"  type="checkbox" onchange="calculate(event)" checked/></span></li>
                        <li>Traditional<span class="price"><input value="100" id="traditional" name="traditional" type="checkbox" onchange="calculate(event)"/></span></li>
                        <li>Beverages<span class="price"><input value="100" id="beverages" name="beverages" type="checkbox" onchange="calculate(event)" checked/></span></li>
                        <li>Snacks<span class="price"><input value="100" id="snacks" name="snacks" type="checkbox" onchange="calculate(event)" checked/></span></li>
                    </ul>
                </div>
                <div class="half">
                    <ul>
                        <li>No. of Guests<span class="price"><select id="guests" name="guests" class="select-box" onchange="calculate(event)"><option value="20">1-20 guests</option><select></span></li>
                        <li>Location<span class="price">
                          <select id="location" name="location" class="select-box" onchange="calculate(event)">
                            <option value="5000">Nyeri</option>
                            <option value="20000">Warumae</option><select>
                          </span></span></li>
                        <li>Start date<span class="price"><input id="start_date" name="start_date" class="input-box" type="text" /></span></li>
                        <li>start time<span class="price"><select id="start_time" name="start_time" class="select-box"><option value="1:00">1:00 hrs</option><option value="2:00">2:00 hrs</option><select></span></li>
                    </ul>
                </div>

                <div class="half">
                  <ul class="info calc-fonts">
                      <li class="hidden">Transport: <strong id="transport_cost">Ksh. </strong></li>
                      <li class="hidden">Food & Drinks: <strong id="food_drink_cost">Ksh. </strong></li>
                      <li class="hidden">Service Charge: <strong id="service_charge">Ksh. </strong></li>
                      <li class="hidden">Total: <strong><u id="total_cost">Ksh. 45,000</u></strong></li>
                      <li class="hidden"><a href="#reserve-form" class="btn-main">Reserve</a></li>
                  </ul>
                </div>
                <div class="half">
                  <a href="#" class="btn-main" onclick="calculate(event,true)">Get Quote</a>
                </div>
                </div> <!-- main id end -->
                <!-- main id -->
                <div id="birthday" class="card hidden">
                <div class="full desserts">
                    <h3>Birthdays</h3>
                </div>
                <div class="half">
                    <ul>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                    </ul>
                </div>
                <div class="half">
                    <ul>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                        <li>Tasty Dessert<span class="price">$9</span></li>
                    </ul>
                </div>
                </div> <!-- main id end -->
                <!-- main id -->
                <div id="graduation" class="card hidden">
                <div class="full drinks">
                    <h3>Graduations</h3>
                </div>
                <div class="half">
                    <ul>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                    </ul>
                </div>
                <div class="half">
                    <ul>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                    </ul>
                </div>
                </div> <!-- main id end -->
                <div id="ruracio" class="card hidden">
                <div class="full ruracio">
                    <h3>Ruracios</h3>
                </div>
                <div class="half">
                    <ul>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                    </ul>
                </div>
                <div class="half">
                    <ul>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                        <li>Craft Beer<span class="price">$7</span></li>
                    </ul>
                </div>
                </div> <!-- main id end -->
            </div> <!-- Menu card DIV end -->
            </div> <!-- Wrapper end -->
        </section> <!-- Menu section end -->
        <section class="dark" id="events">
            <div class="wrap">
                <h2 class="ylw wow fadeInRight">Events</h2>
                <div class="evnt-calendar">
                <div class="scroll wow fadeInUp">
                <!-- first artist -->
                <?php
                $args = array( 'post_type' => 'catering_events', 'posts_per_page' => -1 );
                $loop = new WP_Query( $args );
                while ( $loop->have_posts() ) : $loop->the_post();?>
                <div class="evt">
                    <div class="third">
                        <img src="<?php the_field('image');?>">
                    </div>
                    <div class="two-third">
                        <h3 class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i><?php the_field('date');?><span><?php the_title();?></span></h3>
                        <p><?php the_field('description');?></p>
                    </div>
                </div> <!-- artist end -->
              <?php endwhile;?>
                <!--<div class="evt">
                    <div class="third">
                        <img src="<?php echo get_template_directory_uri();?>/img/event2.jpg">
                    </div>
                    <div class="two-third">
                        <h3 class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i>Dec 31st<span>Entrance: 6PM~</span></h3>
                        <p>Vice heirloom normcore, green juice twee gentrify lomo. Keytar meh tattooed lo-fi tacos chartreuse try-hard. Hammock beard messenger bag pitchfork quinoa enamel pin post-ironic church-key bespoke swag thundercats lo-fi. </p>
                        <a href="#" class="btn-main">Learn more</a>
                    </div>
                </div> --><!-- artist end -->
              <!--  <div class="evt">
                    <div class="third">
                        <img src="<?php echo get_template_directory_uri();?>/img/event3.jpg">
                    </div>
                    <div class="two-third">
                        <h3 class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i>Jan 1st<span>Entrance: 7:30PM~</span></h3>
                        <p>Vice heirloom normcore, green juice twee gentrify lomo. Keytar meh tattooed lo-fi tacos chartreuse try-hard. Hammock beard messenger bag pitchfork quinoa enamel pin post-ironic church-key bespoke swag thundercats lo-fi. </p>
                        <a href="#" class="btn-main">Learn more</a>
                    </div>
                </div> --><!-- artist end -->
                </div> <!-- scroll end -->
                <div class="full wow fadeInUp">
                    <div class="arrows">
                        <a href="#" id="prev" class="left"><i class="fa fa-chevron-left" aria-hidden="true"></i></a>
                        <a href="#" id="next" class="right"><i class="fa fa-chevron-right" aria-hidden="true"></i></a>
                    </div>
                    <ul class="handlers">
                        <li><a class="active" href="#artist1"></a></li>
                        <li><a href="#artist2"></a></li>
                        <li><a href="#artist3"></a></li>
                    </ul>
                </div>
                </div>
            </div>
        </section>
        <section class="light parallax" id="about">
            <div class="wrap about">
                <div class="two-third  wow fadeInLeft">
                    <h2 class="brn sngl">About</h2>
                    <?php
                    $args = array( 'post_type' => 'staff', 'posts_per_page' => 1 );
                    $loop = new WP_Query( $args );
                    while ( $loop->have_posts() ) : $loop->the_post();?>
                    <h5 class="ylw"><?php the_field('designation');?></h5>
                    <p><?php the_field('vision');?></p>
                    <p class="tel"><i class="fa fa-phone" aria-hidden="true"></i><?php the_field('phone');?></p>

                </div>
                <div class="third wow fadeInRight">
                    <img src="<?php the_field('photo');?>">
                </div>
                <?php endwhile;?>
            </div>
        </section>
        <!-- happy hour -->
        <section class="hppy-hr parallax">
            <div class="wrap">
            <h2 class="ylw wow fadeInRight">Why choose us</h2>
            <?php
            $args = array( 'post_type' => 'slogan', 'posts_per_page' => 1 );
            $loop = new WP_Query( $args );
            while ( $loop->have_posts() ) : $loop->the_post();?>
            <p><?php the_field('why_us');?></p>
          <?php endwhile; ?>
            <p class="tel"><i class="fa fa-handshake-o" aria-hidden="true"></i></p>
            </div>
        </section>
        <!-- Map -->
        <div id="map" class="wow fadeIn"></div>
        <!-- Contact -->
        <section class="contact wow fadeIn">
            <div class="wrap subscribe">
                <div class="half">
                    <form role="form" id="reserve-form">
                    <h2 class="ylw sngl">Reservation</h2>
                    <input type="text" placeholder="Your name" required="required">
                    <select class="location"><option value="5000">Nyeri</option>
                    <option value="20000">Warumae</option><select></select>
                    <input type="text" placeholder="Email" required="required">
                    <select class="start_time"><option value="1:00">1:00 hrs</option><option value="2:00">2:00 hrs</option><select>
                    <input class="guests" type="text" placeholder="number of guests" >
                    <input id="end_date" class="start_date" type="text" placeholder="Starts on" value="" >
                    <input class="total_cost" type="text" placeholder="Price" value="" disabled>
                    <input type="submit" val="Subscribe">
                    </form>
                </div>
                <div class="half">
                    <ul class="info">
                      <?php
                      $args = array( 'post_type' => 'company', 'posts_per_page' => 1 );
                      $loop = new WP_Query( $args );
                      while ( $loop->have_posts() ) : $loop->the_post();?>
                        <li><i class="fa fa-phone" aria-hidden="true"></i><?php the_field('phone');?></li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i><?php the_field('email');?></li>
                        <li><i class="fa fa-map-marker" aria-hidden="true"></i><?php the_field('address');?> <br></li>
                        <?php endwhile;?>
                    </ul>
                </div>
            </div>
        </section>
<?php get_footer()?>
