<footer class="wow fadeIn">
            <copy>Copyright @ PMK <?php the_date('Y');?>.</copy>
            <ul class="social">
                <li><a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                <li><a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            </ul>
        </footer>
        <script>window.jQuery || document.write('<script src="<?php echo get_template_directory_uri();?>/js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
        <!-- initialize wow -->
        <script> new WOW().init(); </script>
        <script>
          $( function() {
            $( "#start_date" ).datepicker({
              changeMonth: true,
              changeYear: true
            });
          } );
        </script>
        <script>
          $( function() {
            $( "#end_date" ).datepicker({
              changeMonth: true,
              changeYear: true
            });
          } );
        </script>
        <?php wp_footer();?>
    </body>
</html>
