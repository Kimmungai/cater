<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="<?php echo get_template_directory_uri();?>/apple-touch-icon.png">
        <?php wp_head();?>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <div id="preloader">
            <div id="status"></div>
        </div>
        <div class="hero">
            <div class="wrap">
                <nav>
                    <div class="navi">
                    <a href="#" class="toggle">Menu</a>
                    <ul>
                        <li><a href="#menu" class="smooth"><i class="fa fa-cutlery" aria-hidden="true"></i>Packages</a></li>
                        <li><a href="#events" class="smooth"><i class="fa fa-music" aria-hidden="true"></i>
Events</a></li>
                        <li><a href="#about" class="smooth"><i class="fa fa-info" aria-hidden="true"></i>About</a></li>
                        <li><a href="#map" class="smooth"><i class="fa fa-map-marker" aria-hidden="true"></i>OFFICE</a></li>
                    </ul>
                    <a class="logo" href="index.html"><img src="<?php echo get_template_directory_uri();?>/img/logo.png"></a>
                    </div>
                </nav>
                <div class="heading">
                  <?php
                  $args = array( 'post_type' => 'slogan', 'posts_per_page' => 1 );
                  $loop = new WP_Query( $args );
                  while ( $loop->have_posts() ) : $loop->the_post();?>
                <h2 class="wow fadeInRight" data-wow-delay="1s"><?php the_title(); ?></h2>
                <p class="wow fadeInRight" data-wow-delay="1s"><?php the_field('first_line');?><br> <?php the_field('second_line');?><br> <?php the_field('third_line');?></p>
                  <?php endwhile;?>
                <a href="#map" class="btn-main smooth wow fadeInUp" data-wow-delay="1s">OFFICE</a>
                </div>
            </div>
        </div>
