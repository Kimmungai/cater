<?php
function add_theme_scripts() {
	wp_enqueue_style( 'main-style', get_template_directory_uri() . '/css/main.css', array(), '20182701' );
  wp_enqueue_style( 'calc-style', get_template_directory_uri() . '/css/calc.css', array(), '20182701' );
  wp_enqueue_style( 'animate-style', get_template_directory_uri() . '/css/animate.min.css');
  wp_enqueue_style( 'jquery-style', get_template_directory_uri() . '/css/jquery-ui.min.css');
  wp_enqueue_script( 'Jquery-behavior', get_template_directory_uri() . '/js/vendor/jquery-1.11.2.min.js', true );
  wp_enqueue_script( 'Jquery-uI', 'https://code.jquery.com/ui/1.12.1/jquery-ui.js', true );
  wp_enqueue_script( 'google-maps', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyAJqiG0aHr760nuzJd9Ycy7BSyCn6c3eZQ', array(), null, true );
  wp_enqueue_script( 'main-js', get_template_directory_uri() . '/js/main.js', array(), '20182701', true );
  wp_enqueue_script( 'calc-js', get_template_directory_uri() . '/js/calc.js', array(), '20182701', true );
  wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/js/vendor/modernizr-2.8.3.min.js', true );
  wp_enqueue_script( 'number-js', get_template_directory_uri() . '/js/jquery.number.min.js', true );
  wp_enqueue_script( 'wow-js', get_template_directory_uri() . '/js/wow.min.js', true );

}

add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );

$args = array(
	'width'         => 0,
	'height'        => 0,
	'default-image' => get_template_directory_uri() . '/img/cater.jpg',
	'uploads'       => true,
	'header-text'   => true,
);
add_theme_support( 'custom-header', $args );
